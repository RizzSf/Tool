# Boroide(tm) V0.2.4

Fork of https://github.com/Herrtt/Boronide-Obfuscator | Dead repo | [Archive](https://web.archive.org/web/20220226003911/https://github.com/Herrtt/Boronide-Obfuscator)

# Legality:
All of this code is copyrighted and licensed under AGPL-3.0, and is owned by [Herrtt](https://github.com/Herrtt)<br>
[Original source](https://web.archive.org/web/20220226003911/https://github.com/Herrtt/Boronide-Obfuscator)<br>
[Boronide discord invite (dead invite)](https://www.discord.gg/boronide)<br><br>
List of changes:<br>
Fixed readme file<br>
Fixed package.json (If this was not intended feel free to privately contact me Herrtt)<br>
Removed imgs folder (If this was not intended feel free to privately contact me Herrtt)<br><br>
**THIS CODE IS PROTECTED BY THE AGPL-3.0 LICENSE, AND THIS REPO DOES NOT BREAK THE AFOREMENTIONED LICENSE.**<br>
**Herrtt I have nothing against you xx, I am just a believer in the GPL license, if you wish for me to take down or make changes to parts of the code privately, feel free to contact me at kaed.e**


## Features
* Instruction Shuffle
* Constant Shuffle
* Fake Constants
* Fake Code
* Anti Tamper
* Meme strings

# Installation / Usage

Usage:
```bash
$ cd src && node run.js
```

# License

Any modifications or distributions of this open-source software must be made available with full access to the source, """and the owner of Boronide(tm) ("Herrtt") reserve the right to end your use of the software if believed any prohibited activities at Herrtt's sole discretion"""(Non binding, however please listen to Herrtt if you receive a legal or reasonable moral ask).
![GNU AGPLv3](/LICENSE)
