// generator.js - herrtt
// generates the final script (does not minify tho)


module.exports = {
    Generate: async function(tree, settings) {
    
    
    }
}